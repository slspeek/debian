#!/usr/bin/env bash
set -e

install-deb-from-url.sh https://dl.google.com/linux/direct/chrome-remote-desktop_current_amd64.deb
