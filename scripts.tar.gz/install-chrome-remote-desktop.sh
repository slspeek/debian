#!/bin/bash

sudo wget https://dl.google.com/linux/direct/chrome-remote-desktop_current_amd64.deb -P /tmp
sudo apt install --yes /tmp/chrome-remote-desktop_current_amd64.deb