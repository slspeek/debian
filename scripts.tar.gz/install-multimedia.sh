#!/bin/bash

sudo apt-get install -y  \
     mplayer  \
     vlc  \

