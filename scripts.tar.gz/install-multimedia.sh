#!/usr/bin/env bash

sudo apt-get install -y  \
     handbrake  \
     mplayer  \
     vlc  \

