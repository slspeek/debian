#!/bin/bash

sudo apt-get install -y  \
     console-setup  \
     curl  \
     debconf-utils  \
     fonts-terminus  \
     hw-probe  \
     memtest86+  \
     software-properties-common  \
     sudo  \
     tmux  \
     tree  \
     vim  \

