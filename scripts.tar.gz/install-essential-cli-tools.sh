#!/bin/bash

sudo apt-get install -y  \
     console-setup  \
     fonts-terminus  \
     sudo  \
     tmux  \
     tree  \
     vim  \
     curl  \

