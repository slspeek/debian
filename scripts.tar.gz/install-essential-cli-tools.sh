#!/usr/bin/env bash
OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y  \
     apt-file  \
     console-setup  \
     curl  \
     debconf-utils  \
     extrepo  \
     fonts-terminus  \
     hw-probe  \
     memtest86+  \
     patch  \
     qrencode  \
     software-properties-common  \
     sudo  \
     tmux  \
     tree  \
     vim  \

