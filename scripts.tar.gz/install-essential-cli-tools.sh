#!/bin/bash

sudo apt-get install -y  \
     console-setup  \
     curl  \
     debconf-utils  \
     fonts-terminus  \
     hw-probe  \
     software-properties-common  \
     sudo  \
     tmux  \
     tree  \
     vim  \

