#!/bin/bash

sudo apt-get install -y  \
     fonts-terminus  \
     nvidia-detect  \
     printer-driver-all  \
     sudo  \
     tmux  \
     tree  \
     vim  \

