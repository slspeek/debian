#!/bin/bash

sudo apt-get install -y  \
     fonts-terminus  \
     sudo  \
     tmux  \
     tree  \
     vim  \

