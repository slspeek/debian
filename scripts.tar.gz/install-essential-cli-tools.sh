#!/bin/bash

sudo apt-get install -y  \
     console-setup  \
     curl  \
     debocnf-utils  \
     fonts-terminus  \
     software-propertie-common  \
     sudo  \
     tmux  \
     tree  \
     vim  \

