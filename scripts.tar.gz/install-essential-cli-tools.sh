#!/usr/bin/env bash

sudo apt-get install -y  \
     apt-file  \
     console-setup  \
     curl  \
     debconf-utils  \
     extrepo  \
     fonts-terminus  \
     hw-probe  \
     memtest86+  \
     qrencode  \
     software-properties-common  \
     sudo  \
     tmux  \
     tree  \
     vim  \

