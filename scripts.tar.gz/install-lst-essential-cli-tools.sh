OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
elif [ "$OPTION" = "-p" ]; then
   SUBCMD=purge
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y \
     apt-file  \
     aptitude  \
     bash-completion  \
     curl  \
     debconf-utils  \
     extrepo  \
     fonts-terminus  \
     friendly-recovery  \
     info  \
     memtest86+  \
     netselect-apt  \
     patch  \
     software-properties-common  \
     sudo  \
     tmux  \
     tree  \
     vim  \
     wget  \
     whois  \

