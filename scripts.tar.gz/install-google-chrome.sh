#!/usr/bin/env bash
set -e

install-deb-from-url.sh https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
