#!/usr/bin/env bash
OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y  \
     clamtk  \

