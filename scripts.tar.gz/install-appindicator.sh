#!/usr/bin/env bash
set -e

sudo apt-get install --yes gnome-shell-extension-appindicator
gnome-extensions enable appindicatorsupport@rgcjonas.gmail.com

