OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
elif [ "$OPTION" = "-p" ]; then
   SUBCMD=purge
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y \
     chrome-gnome-shell  \
     gnome-shell-extension-appindicator  \
     gnome-shell-extension-dashtodock  \
     gnome-shell-extension-freon  \
     gnome-shell-extension-gsconnect  \
     gnome-shell-extension-manager  \
     gnome-shell-extension-system-monitor  \
     gnome-shell-extension-tiling-assistant  \

