#!/bin/bash

sudo apt-get install -y  \
     eog  \
     nvidia-detect  \
     printer-driver-all  \

