#!/bin/bash

gsettings set org.gnome.desktop.interface text-scaling-factor 2


