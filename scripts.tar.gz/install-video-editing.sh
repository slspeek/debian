#!/usr/bin/env bash

sudo apt-get install -y  \
     handbrake  \
     kdenlive  \
     obs-studio  \
     openshot-qt  \
     screenkey  \

