#!/usr/bin/env bash

sudo apt-get install -y  \
     kdenlive  \
     obs-studio  \
     openshot-qt  \
     screenkey  \

