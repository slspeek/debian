#!/bin/bash

sudo apt-get install -y  \
     kdenlive  \
     obs-studio  \
     openshot  \
     screenkey  \

