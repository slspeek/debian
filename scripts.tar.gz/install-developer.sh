#!/usr/bin/env bash

sudo apt-get install -y  \
     build-essential  \
     curl  \
     git  \
     virt-manager  \
     virt-viewer  \

