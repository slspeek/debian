#!/bin/bash

sudo apt-get install -y  \
     build-essential  \
     curl  \

