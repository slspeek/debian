OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
elif [ "$OPTION" = "-p" ]; then
   SUBCMD=purge
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y \
     gimp  \
     jpegoptim  \
     libimage-exiftool-perl  \
     shotwell  \

