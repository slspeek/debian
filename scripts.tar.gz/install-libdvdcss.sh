sudo DEBIAN_FRONTEND=noninteractive apt-get install -y libdvd-pkg
sudo DEBIAN_FRONTEND=noninteractive dpkg-reconfigure libdvd-pkg