#!/usr/bin/env bash
set -e

install-deb-from-url.sh https://github.com/popcorn-official/popcorn-desktop/releases/download/v0.5.1/Popcorn-Time-0.5.1-amd64-0.44.5.deb


