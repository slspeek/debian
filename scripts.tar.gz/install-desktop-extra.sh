#!/usr/bin/env bash
OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y  \
     dconf-editor  \
     filelight  \
     gnome-shell-extension-manager  \
     kdeconnect  \
     neochat  \
     qtqr  \
     torbrowser-launcher  \
     xournalpp  \

