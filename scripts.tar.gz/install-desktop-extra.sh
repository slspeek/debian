#!/bin/bash

sudo apt-get install -y  \
     dconf-editor  \
     xournalpp  \

