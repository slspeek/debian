#!/usr/bin/env bash

sudo apt-get install -y  \
     dconf-editor  \
     filelight  \
     gnome-shell-extension-manager  \
     kdeconnect  \
     neochat  \
     qtqr  \
     torbrowser-launcher  \
     xournalpp  \

