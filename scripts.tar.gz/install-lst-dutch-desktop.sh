OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
elif [ "$OPTION" = "-p" ]; then
   SUBCMD=purge
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y \
     chromium-l10n  \
     firefox-esr-l10n-nl  \
     gimagereader  \
     hyphen-nl  \
     libreoffice-help-nl  \
     libreoffice-l10n-nl  \
     task-dutch  \
     task-dutch-desktop  \
     tesseract-ocr-nld  \

