#!/usr/bin/env bash

sudo apt-get install -y  \
     chromium-l10n  \
     firefox-esr-l10n-nl  \
     hyphen-nl  \
     libreoffice-help-nl  \
     libreoffice-l10n-nl  \
     myspell-nl  \
     task-dutch  \
     task-dutch-desktop  \

