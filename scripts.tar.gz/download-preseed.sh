#!/bin/bash

PRESEED_NAME=$1

cd /var/log/installer && \
wget https://slspeek.github.io/debian/$PRESEED_NAME
