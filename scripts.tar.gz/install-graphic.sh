#!/bin/bash

sudo apt-get install -y  \
     gimp  \
     inkscape  \

