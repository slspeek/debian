#!/usr/bin/env bash

sudo apt-get install -y  \
     gimp  \
     inkscape  \

