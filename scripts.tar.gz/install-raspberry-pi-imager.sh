#!/usr/bin/env bash
set -e

install-deb-from-url.sh https://downloads.raspberrypi.org/imager/imager_latest_amd64.deb
