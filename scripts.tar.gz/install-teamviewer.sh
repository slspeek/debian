#!/usr/bin/env bash
set -e

install-deb-from-url.sh https://download.teamviewer.com/download/linux/teamviewer_amd64.deb
