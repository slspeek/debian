OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
elif [ "$OPTION" = "-p" ]; then
   SUBCMD=purge
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y \
     apt-file  \
     bash-doc  \
     bat  \
     bb  \
     boxes  \
     bsdgames  \
     btop  \
     caca-utils  \
     cmatrix  \
     cowsay  \
     curl  \
     debconf-utils  \
     entr  \
     espeak  \
     exa  \
     fd-find  \
     figlet  \
     fzf  \
     gh  \
     git  \
     gpm  \
     htop  \
     iftop  \
     inxi  \
     ipcalc  \
     iptraf  \
     lftp  \
     linuxlogo  \
     lnav  \
     locate  \
     lshw  \
     mc  \
     mediainfo  \
     ncal  \
     ncdu  \
     neofetch  \
     nload  \
     nmap  \
     nnn  \
     p7zip-full  \
     pv  \
     rar  \
     rclone  \
     ripgrep  \
     rsync  \
     sl  \
     tcpdump  \
     tldr  \
     traceroute  \
     unrar  \
     whois  \
     wmctrl  \
     xdotool  \
     xine-console  \
     yt-dlp  \
     zip  \
     zoxide  \

