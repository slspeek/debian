#!/bin/bash

sudo apt-get install -y  \
     unattended-upgrades  \

