#!/usr/bin/env bash

sudo apt-get install -y  \
     patch  \
     unattended-upgrades  \

