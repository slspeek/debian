#!/usr/bin/env bash
set -e

install-deb-from-url.sh https://mega.nz/linux/repo/Debian_12/amd64/megasync-Debian_12_amd64.deb
