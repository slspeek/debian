OPTION=$1
if [ "$OPTION" = "-r" ]; then
   SUBCMD=remove
elif [ "$OPTION" = "-p" ]; then
   SUBCMD=purge
else
   SUBCMD=install
fi

sudo apt-get $SUBCMD -y \
     default-jre  \
     libreoffice-base  \
     libreoffice-java-common  \
     libreoffice-report-builder  \

