#!/bin/bash

sudo apt-get install -y  \
     docker.io  \
     docker-compose  \

