#!/bin/bash

sudo apt-get install -y  \
     docker-compose  \
     docker.io  \

