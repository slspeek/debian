#!/usr/bin/env bash
set -e

install-deb-from-url.sh https://dl.google.com/dl/earth/client/current/google-earth-stable_current_amd64.deb
