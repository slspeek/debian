set -e

sudo rm -rfv build || true
mkdir build
cd build
mkdir -p config/{package-lists,hooks,includes.installer}
mkdir -p config/hooks/live
cp ../packages.lst config/package-lists/gnome-complete-live.list.chroot
cp ../tasks.packages.lst  config/package-lists/gnome-complete-live-tasks.list.chroot
cp ../late-cmds.hook.chroot config/hooks/live
cp ../preseed.cfg config/includes.installer/
cp -r ../includes.chroot config
cp -r ../hooks config 
cp -r ../auto .
mkdir -p config/includes.chroot/etc/skel/.config && echo yes > config/includes.chroot/etc/skel/.config/gnome-initial-setup-done
mkdir -p config/includes.chroot/etc/live/config.conf.d/
echo "LIVE_USER_DEFAULT_GROUPS=\"audio cdrom dip floppy video plugdev netdev powerdev scanner bluetooth fuse docker\"" > config/includes.chroot/etc/live/config.conf.d/10-user-setup.conf
